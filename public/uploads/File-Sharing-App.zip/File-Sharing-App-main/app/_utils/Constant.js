export default{
    desc:'Drag and drop your file directory on our cloud and share it with your friends secuarely with password and send it on email',
}